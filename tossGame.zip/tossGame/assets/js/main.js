/*
    credit: sabbir-shuvo-ux -- github
    name: toss_game
      
*/

// refarance
const btn = document.querySelector('.btn');

function gameMain() {

	// get king/queen
	const king = document.querySelector('#king').checked;
	const queen = document.querySelector('#queen').checked;
	const win = document.querySelector('.win');
	const loss = document.querySelector('.loss');

	if (king === false && queen === false) {
		swal({
		  title: "please select one of the options below",
		  button: "Ok!"
		});
		
		return;
	}


	const frontImg = document.querySelector('.main_img img'); // main img src get
	frontImg.src = 'assets/img/flip.gif'; // animation set

	const num = Math.floor((Math.random() * 2) + 1); // number genarate

	// result
	setTimeout(function() {

		// img set
		if (num === 1) {
			frontImg.src = 'assets/img/coin1.png'
		}
		if(num === 2) {
			frontImg.src = 'assets/img/coin2.png';
		}

		// message show win or loss [ KING ]
		if(num === 1 && king === true){
			win.classList.add('d-block')
			loss.classList.remove('d-block')
		}

		if(num === 2 && king === true){
			loss.classList.add('d-block')
			win.classList.remove('d-block')
		}

		// message show win or loss [ QUEEN ]
		if(num === 1 && queen === true){
			loss.classList.add('d-block')
			win.classList.remove('d-block')
		}

		if(num === 2 && queen === true){
			win.classList.add('d-block')
			loss.classList.remove('d-block')

		}


	}, 1000)
}
btn.addEventListener('click', gameMain);

// selection btn validation
window.addEventListener('load', ()=>{
	document.querySelector('#king').checked = false;
	document.querySelector('#queen').checked = false;
})

function kingValidation() {
	document.querySelector('#king').checked = true;
	document.querySelector('#queen').checked = false;
}

function queenValidation() {
	document.querySelector('#king').checked = false;
	document.querySelector('#queen').checked = true;
}

const formGroup = document.querySelector('.form-group');
formGroup.childNodes[1].addEventListener('click', function() {
	this.classList.add('btn_style-select');
	formGroup.childNodes[5].classList.remove('btn_style-select')
})

formGroup.childNodes[5].addEventListener('click', function() {
	this.classList.add('btn_style-select')
	formGroup.childNodes[1].classList.remove('btn_style-select')
})
