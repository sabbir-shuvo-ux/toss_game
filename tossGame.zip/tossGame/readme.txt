To start the game you have to choose 1 of the options
otherwise you can not start the game.
after click "flip" then you will get one success or lose message


